import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

// Importe o NavController para navegação
import { NavController, IonContent, IonButton, IonIcon } from '@ionic/angular/standalone';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonContent,
    IonButton,
    IonIcon,
  ]
})
export class HomePage implements OnInit {
  // Injete o NavController no construtor
  constructor(private navCtrl: NavController) { }

  ngOnInit() {}

  async goToLoginPage() {
    this.navCtrl.navigateForward('/login');
  }
  async goToCadastroPage() {
    this.navCtrl.navigateForward('/cadastro');
  }
}